# Smart Agriculture ESP32

An ESP32-based field-monitoring prototype that reads air, light, leaf and soil conditions, scans for obstacles with a servo-mounted ultrasonic sensor, and lowers a servo-driven soil probe to measure moisture. All readings are printed to the Serial Monitor.

## Features

- Air temperature and humidity (DHT22 / DHT11)
- Light intensity in lux (BH1750)
- Leaf / object and ambient temperature, contactless (MLX90614)
- Soil moisture with DRY / MODERATE / WET status (analog sensor)
- Left / center / right obstacle scan (HC-SR04 on servo 1)
- Automatic soil probe up/down mechanism (servo 2)

## Hardware

| Component | Purpose |
|-----------|---------|
| ESP32 dev board | Microcontroller |
| DHT22 (or DHT11) | Air temp & humidity |
| BH1750 | Light sensor (I2C) |
| MLX90614 | IR temperature sensor (I2C) |
| Capacitive / resistive soil moisture sensor | Soil moisture (analog) |
| HC-SR04 | Ultrasonic distance |
| 2x servo motors (SG90 / MG90S) | Ultrasonic scanning + soil probe |

## Wiring

| Signal | ESP32 GPIO |
|--------|-----------|
| Servo 1 (ultrasonic scan) | 18 |
| Servo 2 (soil probe) | 19 |
| Ultrasonic TRIG | 5 |
| Ultrasonic ECHO | 34 |
| DHT data | 4 |
| Soil moisture (analog) | 35 |
| I2C SDA (BH1750, MLX90614) | 21 |
| I2C SCL (BH1750, MLX90614) | 22 |

Notes:
- Power servos from a separate 5 V supply if possible, and share GND with the ESP32.
- HC-SR04 ECHO outputs 5 V; use a voltage divider (e.g. 1k + 2k) to bring it down to 3.3 V for GPIO 34.
- GPIO 34 and 35 are input-only, which is fine for ECHO and the analog soil sensor.

## Libraries

Install via Arduino Library Manager:

- ESP32Servo
- DHT sensor library (Adafruit) + Adafruit Unified Sensor
- Adafruit BH1750
- Adafruit MLX90614 Library

Board support: **ESP32 by Espressif** (Boards Manager).

## Getting started

1. Open `smart_agriculture_esp32/smart_agriculture_esp32.ino` in Arduino IDE.
2. Select your ESP32 board and COM port.
3. Upload.
4. Open Serial Monitor at **115200 baud**.

## Calibration

- **Soil sensor:** in `readSoilMoisture()`, `map(soilValue, 4095, 1500, 0, 100)` uses placeholder dry/wet values. Record the raw value in dry air (dry) and in water (wet) and replace `4095` and `1500`.
- **Probe angles:** adjust `PROBE_UP` and `PROBE_DOWN` to match your mechanism.
- **DHT11:** change `DHT_TYPE` from `DHT22` to `DHT11`.

## Sample output

```
SENSOR READINGS
Air Temperature: 28.40 °C
Humidity: 62.10 %
Light Intensity: 15320.00 lux
Leaf/Object Temperature: 27.10 °C
Soil Moisture: 42%
Soil Status: MODERATE
```

## License

MIT
