#include <Wire.h>
#include <ESP32Servo.h>
#include <DHT.h>
#include <Adafruit_BH1750.h>
#include <Adafruit_MLX90614.h>

// ================= PIN DEFINITIONS =================

// Servo motors
#define SERVO1_PIN 18
#define SERVO2_PIN 19

// Ultrasonic
#define TRIG_PIN 5
#define ECHO_PIN 34

// DHT
#define DHT_PIN 4
#define DHT_TYPE DHT22
// If you have DHT11, change DHT22 to DHT11

// Soil moisture
#define SOIL_PIN 35

// ================= OBJECTS =================

Servo servo1;
Servo servo2;

DHT dht(DHT_PIN, DHT_TYPE);

Adafruit_BH1750 bh1750;
Adafruit_MLX90614 mlx = Adafruit_MLX90614();

// ================= SERVO POSITIONS =================

// Servo 1 ultrasonic scanning
const int SERVO1_LEFT   = 0;
const int SERVO1_CENTER = 90;
const int SERVO1_RIGHT  = 180;

// Servo 2 soil probe
// CHANGE THESE AFTER TESTING YOUR MECHANISM
const int PROBE_UP   = 20;
const int PROBE_DOWN = 110;

// ================= SETUP =================

void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println(" SMART AGRICULTURE ESP32");
  Serial.println("================================");

  // Ultrasonic
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Soil sensor
  pinMode(SOIL_PIN, INPUT);

  // I2C
  Wire.begin(21, 22);

  // Servos
  servo1.attach(SERVO1_PIN);
  servo2.attach(SERVO2_PIN);

  servo1.write(SERVO1_CENTER);
  servo2.write(PROBE_UP);

  // DHT
  dht.begin();

  // BH1750
  if (bh1750.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("BH1750: OK");
  } 
  else {
    Serial.println("BH1750: NOT FOUND");
  }

  // MLX90614
  if (mlx.begin()) {
    Serial.println("MLX90614: OK");
  } 
  else {
    Serial.println("MLX90614: NOT FOUND");
  }

  Serial.println("System Ready!");
  Serial.println();
}

// ================= ULTRASONIC FUNCTION =================

float getDistance() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) {
    return -1;
  }

  float distance = duration * 0.0343 / 2;

  return distance;
}

// ================= ULTRASONIC SCANNING =================

void ultrasonicScan() {

  Serial.println();
  Serial.println("----- ULTRASONIC SCAN -----");

  // LEFT
  servo1.write(SERVO1_LEFT);
  delay(500);

  float leftDistance = getDistance();

  Serial.print("LEFT  : ");
  Serial.print(leftDistance);
  Serial.println(" cm");

  // CENTER
  servo1.write(SERVO1_CENTER);
  delay(500);

  float centerDistance = getDistance();

  Serial.print("CENTER: ");
  Serial.print(centerDistance);
  Serial.println(" cm");

  // RIGHT
  servo1.write(SERVO1_RIGHT);
  delay(500);

  float rightDistance = getDistance();

  Serial.print("RIGHT : ");
  Serial.print(rightDistance);
  Serial.println(" cm");

  // Return center
  servo1.write(SERVO1_CENTER);

  Serial.println("----------------------------");
}

// ================= SOIL MOISTURE =================

void readSoilMoisture() {

  int soilValue = analogRead(SOIL_PIN);

  Serial.print("Soil Raw Value: ");
  Serial.println(soilValue);

  // Approximate percentage.
  // CALIBRATE these values according to your sensor.
  int moisturePercent = map(soilValue, 4095, 1500, 0, 100);

  moisturePercent = constrain(moisturePercent, 0, 100);

  Serial.print("Soil Moisture: ");
  Serial.print(moisturePercent);
  Serial.println("%");

  if (moisturePercent < 30) {
    Serial.println("Soil Status: DRY");
  }
  else if (moisturePercent < 70) {
    Serial.println("Soil Status: MODERATE");
  }
  else {
    Serial.println("Soil Status: WET");
  }
}

// ================= DHT SENSOR =================

void readDHT() {

  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  if (isnan(humidity) || isnan(temperature)) {
    Serial.println("DHT: Reading failed");
    return;
  }

  Serial.print("Air Temperature: ");
  Serial.print(temperature);
  Serial.println(" °C");

  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.println(" %");
}

// ================= BH1750 =================

void readBH1750() {

  float lux = bh1750.readLightLevel();

  if (lux < 0) {
    Serial.println("BH1750: Reading failed");
    return;
  }

  Serial.print("Light Intensity: ");
  Serial.print(lux);
  Serial.println(" lux");
}

// ================= MLX90614 =================

void readMLX() {

  float objectTemp = mlx.readObjectTempC();
  float ambientTemp = mlx.readAmbientTempC();

  Serial.print("Leaf/Object Temperature: ");
  Serial.print(objectTemp);
  Serial.println(" °C");

  Serial.print("Ambient Temperature: ");
  Serial.print(ambientTemp);
  Serial.println(" °C");
}

// ================= SOIL PROBE MECHANISM =================

void soilProbeTest() {

  Serial.println();
  Serial.println("===== SOIL PROBE TEST =====");

  // Move probe DOWN
  Serial.println("Probe DOWN");

  servo2.write(PROBE_DOWN);

  delay(1500);

  // Read soil moisture
  Serial.println("Reading Soil Moisture...");

  readSoilMoisture();

  // Keep probe in soil for a few seconds
  delay(3000);

  // Move probe UP
  Serial.println("Probe UP");

  servo2.write(PROBE_UP);

  delay(1500);

  Serial.println("===========================");
}

// ================= MAIN LOOP =================

void loop() {

  Serial.println();
  Serial.println("================================");
  Serial.println("       SENSOR READINGS");
  Serial.println("================================");

  // 1. DHT
  readDHT();

  Serial.println();

  // 2. BH1750
  readBH1750();

  Serial.println();

  // 3. MLX90614
  readMLX();

  Serial.println();

  // 4. Soil sensor
  readSoilMoisture();

  Serial.println();

  // 5. Ultrasonic scanning
  ultrasonicScan();

  // 6. Soil probe mechanism
  soilProbeTest();

  Serial.println();
  Serial.println("Cycle Complete!");
  Serial.println("Waiting 5 seconds...");

  delay(5000);
}
